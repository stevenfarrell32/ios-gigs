//
//  GigController.swift
//  Gigs
//
//  Created by Lambda_School_Loaner_151 on 9/21/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation


class GigController {
    var bearer: String? = ""
    let baseURL = "https://lambdagigs.vapor.cloud/api"
    
}

func signUp() {
    
}
