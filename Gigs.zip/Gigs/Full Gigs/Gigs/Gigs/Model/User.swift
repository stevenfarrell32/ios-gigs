//
//  User.swift
//  Gigs
//
//  Created by Lambda_School_Loaner_151 on 9/21/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation

struct User {
    var username: String
    var password: String
}
